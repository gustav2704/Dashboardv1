﻿MT5 read-only evidence export
Created: 2026-08-17T22:18:45.2079316+02:00
TerminalRoot: C:\Users\Administrador\AppData\Roaming\MetaQuotes\Terminal
Needles: ULTRADAX_D1, 41500119, GDAXI

No MT5 process was started, stopped, or modified.
The charts.csv column expert_block_present distinguishes an actual EA attachment from chart objects/labels.
The matching_objects column is evidence only and must not be used as EA inputs.
