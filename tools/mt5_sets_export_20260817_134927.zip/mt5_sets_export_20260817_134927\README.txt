﻿MT5 read-only evidence export
Created: 2026-08-17T13:49:46.0233440-07:00
TerminalRoot: C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal
Needles: ULTRADAX_D1, 41500119, GDAXI

No MT5 process was started, stopped, or modified.
The charts.csv column expert_block_present distinguishes an actual EA attachment from chart objects/labels.
The matching_objects column is evidence only and must not be used as EA inputs.
